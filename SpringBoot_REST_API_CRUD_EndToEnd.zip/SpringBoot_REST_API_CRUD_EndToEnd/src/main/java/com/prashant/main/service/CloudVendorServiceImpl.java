package com.prashant.main.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.prashant.main.model.CloudVendor;
import com.prashant.main.repository.CloudVendorRepository;

@Service
public class CloudVendorServiceImpl implements CloudVendorService {
	
	CloudVendorRepository cloudVendorRepository;
	
	public CloudVendorServiceImpl(CloudVendorRepository cloudVendorRepository) {
		super();
		this.cloudVendorRepository = cloudVendorRepository;
	}

	@Override
	public String createCloudVendor(CloudVendor cloudvendor) {
		cloudVendorRepository.save(cloudvendor);
		return "Success..";
	}

	@Override
	public String updateCloudVendor(CloudVendor cloudvendor) {
		cloudVendorRepository.save(cloudvendor);
		return "Success..";
	}

	@Override
	public String deleteCloudVendor(String cloudvendorId) {
		cloudVendorRepository.deleteById(cloudvendorId);
		return "Success..";
	}

	@Override
	public CloudVendor getCloudVendor(String cloudVendorId) {
		
		return (CloudVendor) cloudVendorRepository.findById(cloudVendorId).get();
	}

	@Override
	public List<CloudVendor> getAllCloudVendors() {
		
		return cloudVendorRepository.findAll();
	}

}
