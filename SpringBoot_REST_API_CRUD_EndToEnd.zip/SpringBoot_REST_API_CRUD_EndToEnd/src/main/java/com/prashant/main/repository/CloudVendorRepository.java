package com.prashant.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prashant.main.model.CloudVendor;

public interface CloudVendorRepository extends JpaRepository <CloudVendor, String> {
	
	
}
